#!/bin/env bash
set -euo pipefail
echo 'Awe$ome'
